export class Customer {
  id: number;
  name: string;
  lastName: string;
  phone: string;
}
