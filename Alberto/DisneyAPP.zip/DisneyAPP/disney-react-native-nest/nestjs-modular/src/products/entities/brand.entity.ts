export class Brand {
  id: number;
  name: string;
  image: string;
}
