public class Contador {
    public static int contador = 0;

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Contador.contador = contador;
    }
}
